package com.demo.model;

public class HelloWorld {
	public HelloWorld() {
		System.out.println("In Default of HelloWorld..");
	}
	
	public String sayHello() {
		return "Hello World..!!";
	}
}
