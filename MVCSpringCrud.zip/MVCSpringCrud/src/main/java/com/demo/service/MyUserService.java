package com.demo.service;

import com.demo.model.MyUSer;

public interface MyUserService {

	MyUSer checkUser(String uname, String passwd);

}
